# -*- coding: utf-8 -*-

import sys
import xbmcaddon, xbmcgui, xbmcplugin

# Plugin Info
ADDON_ID      = 'plugin.video.rsamusictv'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

def addDir(title, url):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':ICON,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    
if __name__ == '__main__':
    addDir(title="RSA MUSIC"            , url="plugin://plugin.video.youtube/channel/UC4J156Jz2u_CjEyUSmQgh6g/playlists/")
    addDir(title="RSA MUSIC ONE"            , url="plugin://plugin.video.youtube/channel/UCZBJs6hdTN3yy7pisHgD64A/playlists/")
    addDir(title="RSA MUSIC DOIS"            , url="plugin://plugin.video.youtube/channel/UClaTLxbyrnSGansHkQZvbHA/playlists/")
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
